import React from "react";
class BgChanger extends React.Component {
  constructor() {
    super();
    this.state = {
      bgColor: "#AA00CC"
    };
  }
  handlerChangeColor = () => {
    let newColor = "#";
    let hexa = "0123456789ABCDEF".split("");
    for (let i = 0; i < 6; i++) {
      const random = Math.floor(Math.random() * 16);
      newColor += hexa[random];
    }
    console.log(newColor);
  };
  render() {
    document.body.style.backgroundColor = this.state.bgColor;
    return (
      <>
        <button onClick={this.handlerChangeColor}>Change color</button>
        <h1>Color {this.state.bgColor}</h1>
      </>
    );
  }
}
export default BgChanger;
