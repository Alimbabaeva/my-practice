import React from "react";
import ReactDOM from "react-dom";
import { Grid, Row } from "react-flexbox-grid";
import BgChanger from "./components/BgChanger";
class App extends React.Component {
  render() {
    return (
      <Grid>
        <Row>
          <BgChanger></BgChanger>
        </Row>
      </Grid>
    );
  }
}

ReactDOM.render(<App />, document.getElementById("container"));
