setTimeout(() => console.log("message 1"), 0);
// goes to web api, as a queue for async operations

Promise.resolve("message 2").then((msg) => console.log(msg));

console.log("message 3");

// message 3
// message 1
// message 2

// message 1
// message 3
// message 2

// message 3
// message 2
// message 1

// How does javascript handles async code

// call stack, LIFO
// queue - FIFO
