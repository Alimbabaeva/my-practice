// OOP - Object Oriented Programming
// new - it's a constuctor method to instantiate a new instance of a class
// class - blueprint for an instance, instance (object in other languages)

class Student {
  constructor(name) {
    this.name = name;
    this.completed = false;
  }
}

class FancyButton {
  constructor(text, options) {
    this.text = text;
    this.options = options;
  }
}
const buttonsText = ["button1", "button2"];
const buttons = buttonsText.map((text) => new FancyButton(text));
const azizButton = new FancyButton("Aziz", { width: "300px", height: "200px" });

const zarinaStudent = new Student("Zarina");
console.log(zarinaStudent.completed);

// static methods are the methods that can be called without creating an instance
