function sleep(ms) {
  if (!Number.isSafeInteger(ms)) throw new TypeError("The ms must be integer");

  const now = Date.now();
  const finishTime = now + ms;
  console.log(currentLocalTime(now));
  while (true) {
    const nowInWhile = Date.now();
    if (nowInWhile >= finishTime) {
      console.log(currentLocalTime(finishTime));
      return;
    }
  }
}

function currentLocalTime(timestamp) {
  const date = new Date(timestamp);
  return `${date.toLocaleString()}.${date.getMilliseconds()}`;
}

export { sleep };
