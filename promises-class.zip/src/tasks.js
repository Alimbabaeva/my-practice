// Create a new promise called makeServerRequest. Pass in a function with resolve and reject parameters to the constructor.

// resources:
// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise
// https://www.freecodecamp.org/learn/javascript-algorithms-and-data-structures/#es6
// https://dmitripavlutin.com/javascript-promises-settimeout/
// https://javascript.info/async
