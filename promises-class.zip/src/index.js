import { sleep } from "./sleep";
import "./styles.css";

console.clear();

document.getElementById("app").innerHTML = `
<h1>Promises</h1>`;

console.log("before fetch");

// fetch returns a promise
console.log(
  "fetch",
  Promise.resolve("promise result").then((result) => console.log(result)) // promise handler
);

// .then handler only executes on a successful promise

Promise.reject(new Error("promise rejected"))
  .then((val) => console.log(val))
  .catch((err) => console.log(err));

// promise can either resolve (success) or reject (fail)
// initial state of a promise is pending

console.log("after fetch");
console.log("something else");

// before fetch
// fetch Promise {<pending>}
// after fetch
// promise result

// synchronous/blocking code
// asynchronous code - non-blocking code

// create a promise that succeeds and handle success
// create a promise that fails and handle the failure

// Promises

const successPromise = Promise.resolve("resolved").then((val) =>
  console.log(val)
);
console.log({ anotherPromise: successPromise });

const rejectedPromise = Promise.reject(new Error("rejected")).catch((err) =>
  console.error(err)
);

// Promise is a global class

// creating a promise using Promise constructor method
const newPromise = new Promise((resolve, reject) => {
  // resolve("resolved")
  reject("rejected");
});

// Create a new promise called makeServerRequest. Pass in a function with resolve and reject parameters to the constructor.

const makeServerRequest = new Promise((res, rej) => {
  if (true) {
    res("it was resolved"); // resolved value
  }
  rej("it was rejected"); // rejected value
});

const myFetch = (apiUrl) => {
  return new Promise((res, rej) =>
    setTimeout(() => res("network request success"), 2000)
  );
};

const timer = () => {
  return new Promise((res, rej) =>
    setTimeout(() => rej(new Error("timer exceeded")), 1500)
  );
};

const data = Promise.race([myFetch("https://google.com"), timer()])
  .then((res) => console.log({ res }))
  .catch((err) => console.error(err));
// race returns the first promise that settles

// pending -> settles (rejects/resolves)

// u have a lot of fetch requests, they're not dependant on each other
const fetchOne = myFetch("someurl");
const fetchTwo = myFetch("another");
const fetchThree = myFetch("third");
const promises = [fetchOne, fetchTwo, fetchThree];

Promise.all(promises); // check if all successful, if all of them resolved, the result promise will be resolved
// if any of them is rejected, the result promise is rejected
Promise.allSettled(promises); // gives u results
// Promise.allSettled();, returns a fulfilled promise, with the results of each promise

Promise.any(promises); // if at least one is resolved the result promise will have resolved value
Promise.race(promises); // return the result value of the promise that was settled first

new Promise((res, rej) => {
  // sync code, blocking code
  console.log("blocking main code");
  sleep(10000);
  res("done blocking main code");
})
  .then((result) => console.log(result))
  .catch((err) => console.error(err))
  .finally(() => console.log("Promise done"));
// .then .catch .finally are asynchronous

console.log("after promise sleep");

// web workers - concurrency, background operations
// promises are not for background tasks
Promise.resolve(25)
  .then((val) => console.log(val))
  .then((val) => console.log(val));

// async functions

const API_URL = "https://google.com";
async function getTrackData(trackId) {
  try {
    const resp = await myFetch(API_URL);
    const data = await resp.json();
    return data;
  } catch (err) {
    return err;
  }
}

getTrackData(1234)
  .then((trackData) => console.log(trackData))
  .catch((err) => console.log(err));

myFetch(API_URL)
  .then((res) => res.json())
  .then((data) => Promise.resolve(data))
  .catch((err) => Promise.reject(err));

/*
  const url = "google.com"

*/
