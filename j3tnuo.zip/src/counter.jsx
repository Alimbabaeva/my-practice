import React from "react";
class Counter extends React.Component {
constructor(props){
  super(props);
  this.state={
    counterVal: this.props.defaultVal
  };
  // this.decerment=this.decerment.bind(this);// use functinuo as a "decerment=function(){"
}
decerment=()=>{
  if(this.state.counterVal>0){
  this.setState({
    counterVal:this.state.counterVal -1
  })
}
};

increment=()=>{
  if(this.state.counterVal<10){
  this.setState({
    counterVal:this.state.counterVal +1
  })
}
};

reset=()=>{
  this.setState({
    counterVal:0
  });
}

  render(){
    return(
      <div>
        <div>{this.state.counterVal}</div>
        <button onClick={this.decerment}>document</button>
        <button onClick={this.increment}>interet</button>
        <button onClick={this.reset}>Reset</button>
      </div>
    )
  }
}
export default Counter;