import "./styles.css";
import Counter from "./counter";

export default function App() {
  return (
    <div className="App">
      <Counter defaultVal={3}/>
    </div>
  );
}
